// eslint-disable
// this is an auto generated file. This will be overwritten

export const onCreatePet = `subscription OnCreatePet {
  onCreatePet {
    id
    name
    description
  }
}
`;
export const onUpdatePet = `subscription OnUpdatePet {
  onUpdatePet {
    id
    name
    description
  }
}
`;
export const onDeletePet = `subscription OnDeletePet {
  onDeletePet {
    id
    name
    description
  }
}
`;
