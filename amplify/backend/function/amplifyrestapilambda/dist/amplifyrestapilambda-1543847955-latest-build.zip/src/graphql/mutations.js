// eslint-disable
// this is an auto generated file. This will be overwritten

export const createPet = `mutation CreatePet($input: CreatePetInput!) {
  createPet(input: $input) {
    id
    name
    description
  }
}
`;
export const updatePet = `mutation UpdatePet($input: UpdatePetInput!) {
  updatePet(input: $input) {
    id
    name
    description
  }
}
`;
export const deletePet = `mutation DeletePet($input: DeletePetInput!) {
  deletePet(input: $input) {
    id
    name
    description
  }
}
`;
